zhtframees 基于springmvc hibernate shiro freemarker easyui 的开发基础框架，
包含较为完善的权限管理基础部分，代码生成部分
可在此基础上直接进行进一步的开发
所需jar吧包下载地址：http://pan.baidu.com/s/1bn6Omhp