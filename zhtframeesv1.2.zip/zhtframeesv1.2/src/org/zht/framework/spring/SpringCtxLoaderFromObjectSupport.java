/**
 * Copyright (c) 2015 https://github.com/zhaohuatai
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.zht.framework.spring;


import org.springframework.context.support.ApplicationObjectSupport;


public class SpringCtxLoaderFromObjectSupport extends ApplicationObjectSupport {
	

}
