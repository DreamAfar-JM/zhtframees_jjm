/**
 * Copyright (c) 2015 https://github.com/zhaohuatai
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.zht.framework.zhtdao.identity;

public abstract class PKBaseEntity extends PKIdentityEntity{

	private static final long serialVersionUID = 1L;
	
}
