/**
 * Copyright (c) 2015 https://github.com/zhaohuatai
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.zht.framework.uuid;

public class UUIDType {

	public static final String Base58UuidGenerator="org.zht.framework.uuid.Base58UuidGenerator";
	public static final String Base64UuidGenerator="org.zht.framework.uuid.Base64UuidGenerator";
}
