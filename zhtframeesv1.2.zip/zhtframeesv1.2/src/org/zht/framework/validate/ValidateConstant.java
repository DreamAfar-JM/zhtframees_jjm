/**
 * Copyright (c) 2015 https://github.com/zhaohuatai
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.zht.framework.validate;

public class ValidateConstant {

	public static final String BINDING_RESULT_LIST_NAME="_bindingResultList_";
	public static final String BINDING_RESULT_HAS_ERROR="_binding_result_has_error_";
}
