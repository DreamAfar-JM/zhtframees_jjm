/**
 * Copyright (c) 2015 https://github.com/zhaohuatai
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package org.zht.framework.consts;
/**
 * 
 *
 * @ClassName :GlobleConstant     
 * @Description :   
 * @createTime :2015年4月5日上午1:33:41
 * @author zhaohuatai 
 * @version :1.0
 *
 */
public class GlobleConstant {

	
	public static final String pageSalt = "@zhtframework_94DABGioQOq2tTUO0AXYow";

	public static final String error_log = "sys-error";
	public static final String operation_log = "sys_operation";
	
}
