package com.zht.common.demo.service;

import org.zht.framework.service.IBaseService;
import com.zht.common.demo.model.Duser;

public interface IDuserService extends IBaseService<Duser>{
	
}