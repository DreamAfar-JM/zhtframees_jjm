package com.zht.common.demo.dao.impl;

import org.springframework.stereotype.Repository;
import org.zht.framework.zhtdao.base.impl.BaseDaoImpl;
import com.zht.common.demo.dao.IDuserDao;

@Repository
public class DuserDaoImpl extends BaseDaoImpl implements IDuserDao {
 	
 
}