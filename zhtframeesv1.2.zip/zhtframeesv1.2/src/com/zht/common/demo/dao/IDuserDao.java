package com.zht.common.demo.dao;
import org.zht.framework.zhtdao.base.IBaseDao;

public interface IDuserDao extends IBaseDao{
	
}