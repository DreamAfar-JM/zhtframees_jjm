/**
 * Copyright (c) 2015 https://github.com/zhaohuatai
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package com.zht.common.rabc.dao;

import org.zht.framework.zhtdao.base.IBaseDao;
/**
 * 
* @ClassName :IRbacPermissionDao     
* @Description :   
* @createTime :2015年4月3日  下午4:10:30   
* @author ：zhaohuatai   
* @version :1.0
 */
public interface IRbacPermissionDao extends  IBaseDao{

}
