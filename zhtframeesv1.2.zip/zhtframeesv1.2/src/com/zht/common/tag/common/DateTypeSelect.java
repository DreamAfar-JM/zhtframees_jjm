package com.zht.common.tag.common;

import java.util.Arrays;
import java.util.List;

public class DateTypeSelect {
	public static final String[] dateTypeArray=new String[]
	{"yyyy-MM-dd","yyyy-MM-dd HH:mm:ss","HH:mm:ss","yyyy/MM/dd","dd/MM/yyyy"};
	public static final List<String> dateTypeList=Arrays.asList(dateTypeArray);
	 
	
}
