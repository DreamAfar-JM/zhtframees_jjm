package com.zht.common.sys.dao;
import org.zht.framework.zhtdao.base.IBaseDao;

public interface IPositionDao extends IBaseDao{
	
}