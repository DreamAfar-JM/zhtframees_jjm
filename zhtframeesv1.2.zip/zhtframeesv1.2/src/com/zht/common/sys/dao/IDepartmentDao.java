package com.zht.common.sys.dao;
import org.zht.framework.zhtdao.base.IBaseDao;

public interface IDepartmentDao extends IBaseDao{
	
}