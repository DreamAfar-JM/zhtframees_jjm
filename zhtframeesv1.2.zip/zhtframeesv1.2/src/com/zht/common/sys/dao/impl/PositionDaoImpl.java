package com.zht.common.sys.dao.impl;

import org.springframework.stereotype.Repository;
import org.zht.framework.zhtdao.base.impl.BaseDaoImpl;
import com.zht.common.sys.dao.IPositionDao;

@Repository
public class PositionDaoImpl extends BaseDaoImpl implements IPositionDao {
 	
 
}