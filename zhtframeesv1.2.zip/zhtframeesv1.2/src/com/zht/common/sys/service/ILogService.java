package com.zht.common.sys.service;

import org.zht.framework.service.IBaseService;
import com.zht.common.sys.model.Log;

public interface ILogService extends IBaseService<Log>{
	
}