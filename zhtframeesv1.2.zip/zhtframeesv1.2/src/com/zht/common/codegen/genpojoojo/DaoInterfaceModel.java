/**
 * Copyright (c) 2015 https://github.com/zhaohuatai
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package com.zht.common.codegen.genpojoojo;

public class DaoInterfaceModel  {
	
	private String packageName;
	private String entitySimpleClassName;
	
	
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public String getEntitySimpleClassName() {
		return entitySimpleClassName;
	}
	public void setEntitySimpleClassName(String entitySimpleClassName) {
		this.entitySimpleClassName = entitySimpleClassName;
	}



//	public String getExtendsClassName() {
//		return extendsClassName;
//	}
//	public void setExtendsClassName(String extendsClassName) {
//		this.extendsClassName = extendsClassName;
//	}
//	public String getModulePackageName() {
//		return modulePackageName;
//	}
//	public void setModulePackageName(String modulePackageName) {
//		this.modulePackageName = modulePackageName;
//	}
//	public String getEntityClassName() {
//		return entityClassName;
//	}
//	public void setEntityClassName(String entityClassName) {
//		this.entityClassName = entityClassName;
//	}
//	public String getEntityPackageName() {
//		return entityPackageName;
//	}
//	public void setEntityPackageName(String entityPackageName) {
//		this.entityPackageName = entityPackageName;
//	}


}
