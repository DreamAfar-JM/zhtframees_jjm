package com.zht.common.dauth.dao.impl;

import org.springframework.stereotype.Repository;
import org.zht.framework.zhtdao.base.impl.BaseDaoImpl;
import com.zht.common.dauth.dao.IRbacDataPrivilegeDao;

@Repository
public class RbacDataPrivilegeDaoImpl extends BaseDaoImpl implements IRbacDataPrivilegeDao {
 	
 
}