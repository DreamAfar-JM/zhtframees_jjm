package com.zht.common.dauth.dao;
import org.zht.framework.zhtdao.base.IBaseDao;

public interface IRbacDataAccessExpDao extends IBaseDao{
	
}