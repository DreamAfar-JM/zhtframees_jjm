package com.zht.common.dauth.util;

public class DataAuthConst {
	
	public static final String uid="@uid";//userId
	public static final String rid="@rid";//roleId
	public static final String pid="@pid";//positionId
	public static final String did="@did";//departmentId
	
	
}
